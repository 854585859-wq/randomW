// Poster stats — update these numbers when rebuilding
(function () {
  var stats = { concerts: 156, venues: 12, views: 12800 };

  document.getElementById('stat-concerts').textContent = stats.concerts;
  document.getElementById('stat-venues').textContent = stats.venues;
  document.getElementById('stat-views').textContent = stats.views;
})();
